from pathlib import Path

p = Path("android/build.gradle")
text = p.read_text()

if "com.google.gms:google-services" not in text:
    text = text.replace(
        "dependencies {",
        "dependencies {\n        classpath 'com.google.gms:google-services:4.4.2'"
    )

p.write_text(text)
