from pathlib import Path

p = Path("android/app/build.gradle")
text = p.read_text()

if "keystorePropertiesFile" not in text:
    insert = '''
def keystorePropertiesFile = rootProject.file("keystore.properties")
def keystoreProperties = new Properties()
if (keystorePropertiesFile.exists()) {
    keystoreProperties.load(new FileInputStream(keystorePropertiesFile))
}
'''
    text = text.replace("apply plugin: 'com.android.application'", "apply plugin: 'com.android.application'\napply plugin: 'com.google.gms.google-services'\n" + insert)

if "signingConfigs" not in text:
    target = "    buildTypes {"
    replacement = '''
    signingConfigs {
        release {
            if (keystorePropertiesFile.exists()) {
                storeFile file(keystoreProperties['storeFile'])
                storePassword keystoreProperties['storePassword']
                keyAlias keystoreProperties['keyAlias']
                keyPassword keystoreProperties['keyPassword']
            }
        }
    }

    buildTypes {
'''
    text = text.replace(target, replacement)

text = text.replace("            minifyEnabled false", "            minifyEnabled false\n            signingConfig signingConfigs.release")
p.write_text(text)
